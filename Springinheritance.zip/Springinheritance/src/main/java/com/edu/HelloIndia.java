package com.edu;

public class HelloIndia {
	private String Message1;
	private String Message2;
	private String Message3;
	
	public void setMessage1(String message) {
		this.Message1 = message;
	}
	
	public void setMessage2(String message) {
		this.Message2 = message;
	}
	
	public void setMessage3(String message) {
		this.Message3 = message;
	}
	public  void getMessage1() {
		System.out.println("India Message1 : " +Message1);
		
	}
	public void  getMessage2() {
		System.out.println("India Message2 : " +Message2);
	}
	public void getMessage3() {
		System.out.println("India Message3 : " +Message3);
	}
	
	

}
