package com.edu;

public class HelloWorld {
	private String Message1;
	private String Message2;
	
	public void setMessage1(String message) {
		this.Message1 = message;
	}
	public void setMessage2(String message) {
		this.Message2 = message;
	}
	public  void getMessage1() {
		System.out.println("world Message1 :" +Message1);
	}
	public  void  getMessage2() {
		System.out.println("world Message2 :" +Message2);
	}
	
	

}
