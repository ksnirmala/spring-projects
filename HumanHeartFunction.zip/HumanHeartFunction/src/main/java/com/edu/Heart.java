package com.edu;

public class Heart {
	public void pump() {
		System.out.println("Heart is functioning");
	}
	
	

}
