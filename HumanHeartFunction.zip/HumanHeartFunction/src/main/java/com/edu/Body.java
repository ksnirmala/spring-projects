package com.edu;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Body {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
		//Human hob=ctx.getBean("humanobj",Human.class);
		Human hob=(Human) ctx.getBean("humanobj");
		hob.fun();
	}

}
