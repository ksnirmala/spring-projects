package com.edu;

public class Student {
	public void display() {
		System.out.println("hello good morning");
	}

}
