package com.edu;

public class SpringLifeCycle {
	public SpringLifeCycle() {
		System.out.println("No arg constructors");
	}
	public void init() {
		System.out.println("it is init method");
	}
	public void destroy() {
		System.out.println("destroy method");
	}

}
