package com.edu;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Mainapp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx=new AnnotationConfigApplicationContext(MyConfig.class);
		College cob=ctx.getBean("collegeBean",College.class);
		cob.display();
		System.out.println("object of college class"+cob);

	}

}
