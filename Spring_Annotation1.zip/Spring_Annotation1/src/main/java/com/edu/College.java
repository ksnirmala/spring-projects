package com.edu;

import org.springframework.stereotype.Component;

@Component("collegeBean")
public class College {

	public void display() {
		// TODO Auto-generated method stub
		System.out.println("college class display");
		
	}

}
