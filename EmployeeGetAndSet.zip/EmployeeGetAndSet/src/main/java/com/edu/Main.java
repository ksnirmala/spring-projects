package com.edu;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	static ApplicationContext act;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		act=new ClassPathXmlApplicationContext("spring.xml");
		Employee emp=(Employee) act.getBean("eob");
		emp.display();
		Employee emp1=(Employee) act.getBean("eob1");
		System.out.println(emp1.toString());
		

	}

}
