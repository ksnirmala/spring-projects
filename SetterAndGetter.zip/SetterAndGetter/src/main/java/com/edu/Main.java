package com.edu;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx;
		ctx=new ClassPathXmlApplicationContext("spring.xml");
		Student s=(Student) ctx.getBean("s");
		s.display();
		Student s1=(Student) ctx.getBean("s1");
		s1.display();

	}

}
