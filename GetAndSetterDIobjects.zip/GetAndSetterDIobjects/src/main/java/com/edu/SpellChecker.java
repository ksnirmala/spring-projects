package com.edu;

public class SpellChecker {

	public void checkSpelling() {
		System.out.println("all the spelling correct");
		
	}
	


}
