package com.edu;

public class TextEditor {
	private SpellChecker spellChecker;

	
	
	public SpellChecker getSpellChecker() {
		return spellChecker;
	}



	public void setSpellChecker(SpellChecker spellChecker) {
		this.spellChecker = spellChecker;
	}



	public void SpellCheck() {
		System.out.println("texteditor function");
		spellChecker.checkSpelling();
		
	}



}
