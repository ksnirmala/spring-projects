package com.edu;

public class Employee {

}
