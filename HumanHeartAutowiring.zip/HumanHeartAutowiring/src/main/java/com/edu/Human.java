package com.edu;

public class Human {
	private Heart heart;
/*
	public Heart getHeart() {
		return heart;
	}

	public void setHeart(Heart heart) {
		this.heart = heart;
	}
	public void heartFunction()
	{
		System.out.println("Human function calling heart");
		heart.heartFunction();
	}*/
    
	public Human(Heart heart) {
		super();
		this.heart = heart;
	}
	public void heartFunction()
	{
		System.out.println("Human function calling heart");
		heart.heartFunction();
	}

}
//in autowire is 3 types
//byName,byType,byConstructor
//byName is using class name and byTypae is using object name