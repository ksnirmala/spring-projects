package com.edu;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Body {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
		//Human hob=ctx.getBean("humanobj",Human.class);
		Human hob=(Human) ctx.getBean("human");
		hob.heartFunction();

	}

}
