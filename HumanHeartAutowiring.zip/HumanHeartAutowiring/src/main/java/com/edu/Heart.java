package com.edu;

public class Heart {
	public void heartFunction() {
		System.out.println("Heart is functioning");
	}

}
