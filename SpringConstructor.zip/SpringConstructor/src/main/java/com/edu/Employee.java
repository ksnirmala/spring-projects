package com.edu;

public class Employee {
	private int empid;
	private String empname;
	private float empsal;
	public Employee(int empid, String empname, float empsal) {
		super();
		this.empid = empid;
		this.empname = empname;
		this.empsal = empsal;
	}
	void display() {
		System.out.println("Name="+empname);
		System.out.println("Id="+empid);
		System.out.println("Salary="+empsal);
	}

}
