package com.edu;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	static ApplicationContext act;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		act=new ClassPathXmlApplicationContext("spring.xml");
		Employee obj=(Employee) act.getBean("dem");
		obj.display();

	}

}
