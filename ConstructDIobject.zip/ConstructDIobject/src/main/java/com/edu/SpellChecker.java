package com.edu;

public class SpellChecker {
	public SpellChecker() {
		
		System.out.println("spellchecker constructor");
	}
	public void spellCheck() {
		System.out.println("spell check called");
	}

}
