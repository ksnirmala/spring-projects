package com.edu;

public class TextEditor {
	SpellChecker sp;
	public TextEditor(SpellChecker sp) {
		System.out.println("inside texteditor constructor");
		this.sp=sp;
	}
	public void textSpellcheck() {
		sp.spellCheck();
	}
	

}
